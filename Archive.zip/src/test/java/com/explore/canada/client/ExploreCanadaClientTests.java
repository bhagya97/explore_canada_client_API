package com.explore.canada.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExploreCanadaClientTests {

    @Test
    void contextLoads() {
    }

}
